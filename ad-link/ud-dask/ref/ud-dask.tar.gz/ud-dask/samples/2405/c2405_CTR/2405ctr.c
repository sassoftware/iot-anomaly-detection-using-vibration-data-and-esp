#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>
#include <string.h>
#include "udask.h"

#define TIMEBASE 80000000
#define _INFINIT_PULSE_OUT_ // Inifinite Pulse Output
//#undef _INFINIT_PULSE_OUT_ // 40 Pulses Output

int main(int argc, char **argv)
{
    I16 card, err;
    U16 card_num;
    U16 GCtr;
    U16 wDIType = GPIO_IGNORE_CONFIG;
    U32 GPTC_Val;
    int n;
    U16 MajorSelMode;

    printf("This sample performs GPTC operations.\n");

    printf("Card Number? ");
    n = scanf(" %hd", &card_num);
    if( n == 0 )
    {
       printf(" Only integar Card Number is valid \n" ); 
       exit(0);
    }

    card = UD_Register_Card(USB_2405, card_num);
    if(card<0){
        printf("UD_Register_Card Error: %d\n", card);
        exit(1);
    }

    printf("Timer-Counter Number? [0~1] ");
    n = scanf(" %hd", &GCtr);
    if( n == 0 )
    {
       printf(" Only integar Timer-Counter Number is valid \n" ); 
       goto ERR_RET;
    }

    if( (GCtr != 0) && (GCtr != 1) ){
        printf("Invalid counter number, set to GPTC 0...\n");
        printf("Press any key to continue...\n");
        getch();
        GCtr = 0;
    }

    clrscr();
    printf(" \n");
    printf(" (0) Counter Input Mode.\n");
    printf(" (1) Pulse Output Mode.\n");
    printf(" Which GPTC mode to be performed? [0~1] ");
    n = scanf(" %hd", &MajorSelMode);
    if( n == 0 )
    {
       printf(" Only integer GPTC mode is valid \n" ); 
       goto ERR_RET;
    }

    if(MajorSelMode>1){
        printf(" Invalid Mode. set to Counter Input Mode.\n");
        printf(" Press any key to continue...\n");
        getch();
        MajorSelMode = 0;
    }

    switch( MajorSelMode )
    {
  	case 0 : 
    		wDIType = P2405_COUNTER_INPUT;
    		break;
    
   	case 1 : 
    		wDIType = P2405_PULSE_OUTPUT;
    		break;    
    }
    
    switch( GCtr )
    {
    	case 0:
    		if ((err = UD_DIO_2405_Config ( card, wDIType, GPIO_IGNORE_CONFIG )) != NoError )
    		{
         		printf("UD_DIO_2405_Config error=%d", err);
        		UD_Release_Card( card );
        		return(2);   
    		}
    	        break;
    		    
    	case 1:
    		if ((err = UD_DIO_2405_Config ( card, GPIO_IGNORE_CONFIG, wDIType )) != NoError )
    		{
         		printf("UD_DIO_2405_Config error=%d", err);
        		UD_Release_Card( card );
        		return(2);   
    		}
    	        break; 
    }


    if( wDIType == P2405_COUNTER_INPUT )
    {
	if ((err = UD_CTR_Control ( card, GCtr, UD_CTR_Polarity_Positive|UD_CTR_Reset_Rising_Edge_Counter )) != NoError )
	{
         	printf("UD_CTR_Control error=%d", err);
        	UD_Release_Card( card );
        	return(3);
	}
    }
		
    /*Clear GPTC*/
    err = UD_GPTC_Clear(card, GCtr);
    if(err != NoError){
        printf("UD_GPTC_Clear Error: %d\n", err);
        goto ERR_RET;
    }

    clrscr();
    switch(MajorSelMode)
    {
        case 0:
            do{
                err = UD_CTR_ReadEdgeCounter ( card, GCtr, &GPTC_Val );
                clrscr();
                printf("/*---------------------------------*/\n");
                printf(" GPTC Number: %d\n", GCtr);
                printf(" Read Count: %d\n\n", GPTC_Val);
                printf("      You can press Enter to stop...\n");
                printf("/*---------------------------------*/\n");
                usleep(1000);
            }while(!kbhit());
            break;
            
        case 1:       
            /*Setup GPTC*/
#ifdef _INFINIT_PULSE_OUT_ // Inifinite Pulse Output
            err = UD_GPTC_Setup(card, GCtr, ContGatedPulseGenPWM, GPTC_CLK_SRC_Int, GPTC_OUTPUT_HACTIVE, 80000, 0/*dwLReg2_Val*/, 40/*dwPulseCount*/);
#else
            err = UD_GPTC_Setup(card, GCtr, MultipleGatedPulseGen, GPTC_CLK_SRC_Int, GPTC_OUTPUT_HACTIVE, 0, 800000/*dwLReg2_Val*/, 40/*dwPulseCount*/);
#endif             
            if(err != NoError){
                printf("UD_GPTC_Setup Error: %d\n", err);
                goto ERR_RET;
            }

            /*Enable Counter*/
            err = UD_GPTC_Control(card, GCtr, IntENABLE, 1);
            if(err != NoError){
                printf("UD_GPTC_Control(IntENABLE) Error: %d\n", err);
                goto ERR_RET;
            }

            printf("\n Press any key to terminate Pulse-out...\n");
            getch();

            break;

    }


    /*Disable Counter*/
    UD_GPTC_Control(card, GCtr, IntENABLE, 0);
ERR_RET:
    UD_GPTC_Clear(card, GCtr);
    
    UD_Release_Card(card);

    printf("\n Press any key to exit...\n");
    getch();

    return 0;
}

