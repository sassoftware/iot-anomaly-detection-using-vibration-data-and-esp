#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>
#include <string.h>
#include "udask.h"

#define READCOUNT 10240

int main(int argc, char **argv)
{
    I16 card, err;
    U16 card_num;
    U16 ChanCtrl = ( P2405_AI_DisableIEPE | P2405_AI_Coupling_None | P2405_AI_Differential);
    U16 ConvSrc = P2405_AI_CONVSRC_INT;	
    U16 TrigMode = P2405_AI_TRGMOD_GATED;
    U16 TrigCtrl = P2405_AI_TRGSRC_DTRIG | P2405_AI_Gate_PauseLow; 
    U32 TriggerLvel = 0;  /* Ignore for P2405_AI_TRGMOD_GATED */
    U32 ReTriggerCount = 0; /*Ignore if trigger mode is gated trigger*/
    U32 DLY1Cnt = 0; /* Ignore for P2405_AI_TRGMOD_GATED */
    U32 DLY2Cnt = 0; /* Ignore for P2405_AI_TRGMOD_GATED */ 
    U32 RDBuffer[READCOUNT];    
    F64 VBuffer[READCOUNT];
    U32 AI_ReadCount = READCOUNT; /*AI read count*/
    U16 Channel = 0; /*AI channel to be read*/
    U16 AdRange = AD_B_10_V; /*AI range*/
    F64 fSamplerate = 20000.0f;    
    BOOLEAN Stopped = FALSE;
    U32 AccessCnt = 0;
    FILE *w_file;
    char FileName[] = "ai_data.dat";
    U32 i;
    int n;

    memset(RDBuffer, '\0', READCOUNT*sizeof(U32));
    memset(VBuffer, '\0', READCOUNT*sizeof(F64));
    if(!(w_file=fopen(FileName, "w"))){
        printf("file open error...\n");
        exit(1);
    }
    fprintf(w_file, "Channel %d,\n", Channel);
    printf("This sample performs continuous AI acquisition with Gated trigger\n");
    printf("from AI Channel %d at %6.3lf Hz sampling rate.\n", Channel, fSamplerate);

    /*Open and Initialize Devie*/
    printf("Card Number? ");
    n = scanf(" %hd", &card_num);
    if( n == 0 )
    {
       printf(" Only integar Card Number is valid \n" ); 
       exit(0);
    }

    card = UD_Register_Card(USB_2405, card_num);
    if(card<0){
        printf("UD_Register_Card Error: %d\n", card);
        fclose(w_file);
        exit(1);
    }

    // Configure the DI/TimerCounter port
    err = UD_DIO_2405_Config( card, P2405_DIGITAL_INPUT, GPIO_IGNORE_CONFIG );
    if(err != NoError){
        printf("UD_DIO_2405_Config Error: %d\n", err);
        UD_Release_Card(card);    
        fclose(w_file);
        exit(1);
    } 


    /*Configure AI*/
    err = UD_AI_2405_Chan_Config( card, ChanCtrl, ChanCtrl, ChanCtrl, ChanCtrl );
    if(err != NoError)
    {
        printf("UD_AI_2405_Chan_Config Error: %d\n", err);
        UD_Release_Card(card);
        fclose(w_file);
        exit(1);

    }

    err = UD_AI_2405_Trig_Config( card, ConvSrc, TrigMode, TrigCtrl, ReTriggerCount, DLY1Cnt, DLY2Cnt, TriggerLvel );
    if(err != NoError)
    {
        printf("UD_AI_2405_Trig_Config Error: %d\n", err);
        UD_Release_Card(card);
        fclose(w_file);
        exit(1);

    }
    
    /*Disable Double Buffer Mode*/
    err = UD_AI_AsyncDblBufferMode(card, 0);
    if(err != NoError){
        printf("UD_AI_AsyncDblBufferMode Error: %d\n", err);
        UD_Release_Card(card);   
        fclose(w_file);             
        exit(1);
    }

    /*Start AI Acquisition*/
    err = UD_AI_ContReadChannel( card, Channel, AdRange, (U16*)RDBuffer, AI_ReadCount, fSamplerate, ASYNCH_OP );
    if(err != NoError){
        printf("UD_AI_ContReadChannel Error: %d\n", err);
        UD_Release_Card(card);
        fclose(w_file);
        exit(1);
    }

    printf("\nWait Gated Positive Trigger from GPI0...\n");
    do{
        err = UD_AI_AsyncCheck(card, &Stopped, &AccessCnt);
        if(err != NoError){
            printf("AI_AsyncCheck Error: %d\n", err);
            UD_AI_AsyncClear(card, &AccessCnt);
            UD_Release_Card(card);
            fclose(w_file);
            exit(1);
        }
    }while((!kbhit())&&(!Stopped));

    err = UD_AI_AsyncClear(card, &AccessCnt);
    if(err != NoError){
        printf("AI_AsyncClear Error: %d\n", err);
        UD_AI_AsyncClear(card, &AccessCnt);
        UD_Release_Card(card);
        fclose(w_file);
        exit(1);
    }

    if(Stopped)
        printf("\n\nAI Acquisition done...\n");
    else
        printf("\n\nAI Acquisition has been stopped manually...\n");

    printf("Write %d samples of Buffer to %s file...\n\n", AccessCnt, FileName);
    fprintf(w_file, "Raw Data, Scaled Voltage,\n");
    UD_AI_ContVScale32(card, AdRange, 0, RDBuffer, VBuffer, AccessCnt);
    for(i=0; i<AccessCnt; i++){
        fprintf(w_file, "0x%x, %6.4f,\n", RDBuffer[i], VBuffer[i]);
    }

    UD_Release_Card(card);
    fclose(w_file);

    printf("\nPress any key to exit...\n");
    getch();
    return 0;
}

