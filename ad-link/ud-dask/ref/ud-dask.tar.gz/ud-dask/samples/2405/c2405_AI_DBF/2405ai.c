#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>
#include <string.h>
#include "udask.h"

#define AI_COUNT		    20480

int main(int argc, char **argv)
{
    I16 card, err;
    U16 card_num;
    U16 ChanCtrl = ( P2405_AI_DisableIEPE | P2405_AI_Coupling_None | P2405_AI_Differential);
    U16 ConvSrc = P2405_AI_CONVSRC_INT;	
    U16 TrigMode = P2405_AI_TRGMOD_POST;
    U16 TrigCtrl = P2405_AI_TRGSRC_SOFT;      
    U32 TriggerLvel = 0;  /* Ignore for P2405_AI_TRGSRC_SOFT */
    U32 ReTriggerCount = 0; /*Ignore in Double Buffer Mode*/
    U32 DLY1Cnt = 0; /* Ignore for P2405_AI_TRGSRC_SOFT */
    U32 DLY2Cnt = 0; /* Ignore for P2405_AI_TRGSRC_SOFT */
    U32 AI_ReadCount = AI_COUNT;
    F64 fSamplerate = 20000.0f;    
    U16 Channel = 0;
    U16 AdRange = AD_B_10_V;
    BOOLEAN Stopped = FALSE;
    BOOLEAN HalfReady = FALSE;
    U32 AccessCnt = 0;
    U16 BufIdx = 0;
    U16 overrunFlag = 0;
    U8 FileName[] = "ai_data";
    int n;
    /*--------------------------------*/

    printf("This sample performs infinite AI acquisition from AI Channel %d\n", Channel);
    printf("at %6.3lf Hz sampling rate by Double buffer mode.\n\n", fSamplerate );

    /*Open and Initialize Device*/
    printf("Card Number? ");
    n = scanf(" %hd", &card_num);
    if( n == 0 )
    {
       printf(" Only integar Card Number is valid \n" ); 
       exit(0);
    }

    card = UD_Register_Card(USB_2405, card_num);
    if(card<0){
        printf("UD_Register_Card Error: %d\n", card);
        exit(1);
    }

    /*Configure AI*/
    err = UD_AI_2405_Chan_Config( card, ChanCtrl, ChanCtrl, ChanCtrl, ChanCtrl );
    if(err != NoError)
    {
        printf("UD_AI_2405_Chan_Config Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);

    }  										   

    err = UD_AI_2405_Trig_Config( card, ConvSrc, TrigMode, TrigCtrl, ReTriggerCount, DLY1Cnt, DLY2Cnt, TriggerLvel );
    if(err != NoError)
    {
        printf("UD_AI_2405_Trig_Config Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);

    }

    /*Enable Double Buffer Mode*/
    err = UD_AI_AsyncDblBufferMode(card, 1); // single-buffer mode
    if(err != NoError)
    {
        printf("UD_AI_AsyncDblBufferMode Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);
    }

    BufIdx = 0;
    
    /*AI Acquisition Start*/
    err = UD_AI_ContReadChannelToFile(card, Channel, AdRange, FileName, AI_ReadCount, fSamplerate, ASYNCH_OP);
    if(err != NoError){
        printf("AI_ContReadChannel Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);
    }
    
    printf("\nAI Infinite Acquisition is started...\n");
    do{
        /*Check Buffer Ready*/
        err = UD_AI_AsyncDblBufferHalfReady(card, &HalfReady, &Stopped);
        if(err != NoError){
            printf("UD_AI_AsyncDblBufferHalfReady Error: %d\n", err);
            UD_AI_AsyncClear(card, &AccessCnt);
            UD_Release_Card(card);
            exit(1);
        }

        if(HalfReady)
        {                    	
            if(BufIdx==0)
            {
                /*
                 * The acquired AI data are stored in buffer 0,
                 * You can process the data of buffer 0 in HERE if you need.
                 */
                printf("\nBuffer0 Half Ready...\n");
                printf("Write %d samples of Buffer0 to %s.dat file...\n", (AI_ReadCount/2), FileName);
                UD_AI_AsyncDblBufferToFile(card);
                UD_AI_AsyncDblBufferOverrun(card, 0, &overrunFlag);
                if(overrunFlag){
                    printf("OVERRUN...\n");
                    UD_AI_AsyncDblBufferOverrun(card, 1, &overrunFlag);
                }
                BufIdx = 1;
                printf("                              Press Enter to stop...\n");
            }
            else{
                /*
                 * The acquired AI data are stored in buffer 1,
                 * You can process the data of buffer 1 in HERE if you need.
                 */
                printf("\nBuffer1 Half Ready...\n");
                printf("Write %d samples of Buffer1 to %s.dat file...\n", (AI_ReadCount/2), FileName);
                UD_AI_AsyncDblBufferToFile(card);
                UD_AI_AsyncDblBufferOverrun(card, 0, &overrunFlag);
                if(overrunFlag){
                    printf("OVERRUN...\n");
                    UD_AI_AsyncDblBufferOverrun(card, 1, &overrunFlag);
                }
                BufIdx = 0;
                printf("                              Press Enter to stop...\n");
            }
        }
    }while(!kbhit());

    /*Clear AI Setting and Get Remaining data*/
    err = UD_AI_AsyncClear(card, &AccessCnt);
    if(err != NoError){
        printf("AI_AsyncClear Error: %d\n", err);
        UD_AI_AsyncClear(card, &AccessCnt);
        UD_Release_Card(card);
        exit(1);
    }

    if(BufIdx==0)
    {
        printf("\nLast %d samples of Buffer0 had been written to %s.dat file...\n", AccessCnt, FileName);
    }
    else
    {
        printf("\nLast %d samples of Buffer1 had been written to %s.dat file...\n", AccessCnt, FileName);
    }


    UD_Release_Card(card);

    printf("\nPress any key to exit...\n");
    getch();
    return 0;
}
