#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>
#include <string.h>

#include "udask.h"
#include "usbthermo.h"


int main(int argc, char **argv)
{
    I16 card, err;
    U16 card_num;
    double fTemp, fVoltage, fColdJunc;

    int n;

    fVoltage = 0.03; // 0.03mV

    printf("This sample read the temp. sensors for Cold-Junction temp. sensors\n");
    printf("Card Number? ");
    n = scanf(" %hd", &card_num);
    if( n == 0 )
    {
       printf(" Only integar Card Number is valid \n" ); 
       exit(0);
    }

    card = UD_Register_Card(USB_2401, card_num);
    if(card<0){
        printf("UD_Register_Card Error: %d\n", card);
        exit(1);
    }

    err = UD_Read_ColdJunc_Thermo(card, &fColdJunc );
    if(err != NoError)
    {
        printf("UD_Read_ColdJunc_Thermo() failed!,  Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);

    }
    printf(" ColdJunc Sensor = %.06lf\n", fColdJunc );

    err = ADC_to_Thermo( THERMO_K_TYPE, fVoltage, fColdJunc, &fTemp );
    printf(" ADC_to_Thermo() = %0.2f\n", fTemp );

    printf(" Press any key to exit...\n");     getch();
    /*Configure AI Channel*/

    UD_Release_Card(card);
    
    return 0;
}

