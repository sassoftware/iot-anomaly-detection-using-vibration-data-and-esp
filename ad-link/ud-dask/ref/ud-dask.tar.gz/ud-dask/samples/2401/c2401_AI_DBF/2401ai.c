#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>
#include <string.h>
#include "udask.h"

#ifndef U2401_AI_CHANNEL_MAX
#define U2401_AI_CHANNEL_MAX  4
#endif

#define AI_COUNT		2048
#define CHANNELCOUNT		1

int main(int argc, char **argv)
{
    I16 card, err;
    U16 card_num;

    U16 TrigCtrl = P2401_AI_TRGSRC_SOFT|P2401_AI_TRGMOD_POST;
    U32 AI_ReadCount = AI_COUNT; /*AI read count per one buffer*/
    U16 NumChans = CHANNELCOUNT; /*AI Channel Counts to be read*/
    U16 Chans[U2401_AI_CHANNEL_MAX]; /*AI Channels array*/
    U16 AdRanges[U2401_AI_CHANNEL_MAX]; /*AI Ranges array*/
    F64 fSampleRate = 500.0f;    
    BOOLEAN Stopped = FALSE;
    BOOLEAN HalfReady = FALSE;        
    U32 AccessCnt = 0;
    U16 BufIdx = 0;
    U8 FileName[] = "ai_data";

    int n;
    /*--------------------------------*/

    {
    	  Chans[0] = 0;
    	  AdRanges[0] = AD_B_12_5_V;
    		
    	  Chans[1] = 1;
    	  AdRanges[1] = AD_B_12_5_V;    		

    	  Chans[2] = 2;
    	  AdRanges[2] = AD_B_12_5_V;    		

    	  Chans[3] = 3;
    	  AdRanges[3] = AD_B_12_5_V;    		
    }
    
    printf("This sample performs infinite AI acquisition\n");
    printf("at %6.3lf Hz sampling rate by Double buffer mode.\n\n", fSampleRate );

    /*Open and Initialize Device*/
    printf("Card Number? ");
    n = scanf(" %hd", &card_num);
    if( n == 0 )
    {
       printf(" Only integar Card Number is valid \n" ); 
       exit(0);
    }

    card = UD_Register_Card(USB_2401, card_num);
    if(card<0){
        printf("UD_Register_Card Error: %d\n", card);
        exit(1);
    }

    /*Configure AI*/
    err = UD_AI_2401_Config( card, P2401_Voltage_2D5V_Above, P2401_Voltage_2D5V_Above, P2401_Current, P2401_RTD_4_Wire, TrigCtrl );
    if(err<0)
    {
        printf("UD_AI_2401_Config Error: %d\n", err);
        exit(1);
    }	

    /*Enable Double Buffer Mode*/
    err = UD_AI_AsyncDblBufferMode(card, 1); // single-buffer mode
    if(err != NoError)
    {
        printf("UD_AI_AsyncDblBufferMode Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);
    }

    BufIdx = 0;
    
    /*AI Acquisition Start*/
    err = UD_AI_ContReadMultiChannelsToFile(card, NumChans, Chans, AdRanges, FileName, AI_ReadCount, fSampleRate, ASYNCH_OP);
    if(err != NoError){
        printf("UD_AI_ContReadMultiChannelsToFile Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);
    }
    
    printf("\nAI Infinite Acquisition is started...\n");
    do{
        /*Check Buffer Ready*/
        err = UD_AI_AsyncDblBufferHalfReady(card, &HalfReady, &Stopped);
        if(err != NoError){
            printf("UD_AI_AsyncDblBufferHalfReady Error: %d\n", err);
            UD_AI_AsyncClear(card, &AccessCnt);
            UD_Release_Card(card);
            exit(1);
        }

        if(HalfReady)
        {                    	
            if(BufIdx==0)
            {
                /*
                 * The acquired AI data are stored in buffer 0,
                 * You can process the data of buffer 0 in HERE if you need.
                 */
                printf("\nBuffer0 Half Ready...\n");
                printf("Write %d samples of Buffer0 to %s.dat file...\n", (AI_ReadCount/2), FileName);
                UD_AI_AsyncDblBufferToFile(card);
                BufIdx = 1;
                printf("                              Press Enter to stop...\n");
            }
            else{
                /*
                 * The acquired AI data are stored in buffer 1,
                 * You can process the data of buffer 1 in HERE if you need.
                 */
                printf("\nBuffer1 Half Ready...\n");
                printf("Write %d samples of Buffer1 to %s.dat file...\n", (AI_ReadCount/2), FileName);
                UD_AI_AsyncDblBufferToFile(card);
                BufIdx = 0;
                printf("                              Press Enter to stop...\n");
            }
        }
    }while(!kbhit());

    /*Clear AI Setting and Get Remaining data*/
    err = UD_AI_AsyncClear(card, &AccessCnt);
    if(err != NoError){
        printf("AI_AsyncClear Error: %d\n", err);
        UD_AI_AsyncClear(card, &AccessCnt);
        UD_Release_Card(card);
        exit(1);
    }

    if(BufIdx==0)
    {
        printf("\nLast %d samples of Buffer0 had been written to %s.dat file...\n", AccessCnt, FileName);
    }
    else
    {
        printf("\nLast %d samples of Buffer1 had been written to %s.dat file...\n", AccessCnt, FileName);
    }


    UD_Release_Card(card);

    printf("\nPress any key to exit...\n");
    getch();
    return 0;
}
