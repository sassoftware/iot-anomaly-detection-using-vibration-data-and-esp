#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>
#include <string.h>
#include "udask.h"


int main(int argc, char **argv)
{
    I16 card, err;
    U16 card_num;

    U16 wMAvgStage = P2401_Polling_MAvg_16_Sampes;
    U16 wPollSpeed = P2401_ADC_80_SPS;    
    U16 wAdType = P2401_Voltage_2D5V_Above;

    U16 Channel[4] = {0, 1, 2, 3};
    U16 AdRange[4] = {AD_B_12_5_V, AD_B_12_5_V, AD_B_12_5_V, AD_B_12_5_V };
    U32 AIValue[4];
    F64 Voltage;
    int n;

    printf("This sample acquires analog voltage from AI Channel 0 with polling mode.\n");
    printf("Card Number? ");
    n = scanf(" %hd", &card_num);
    if( n == 0 )
    {
       printf(" Only integar Card Number is valid \n" ); 
       exit(0);
    }

    card = UD_Register_Card(USB_2401, card_num);
    if(card<0){
        printf("UD_Register_Card Error: %d\n", card);
        exit(1);
    }


    /*Configure AI Channel*/
    err = UD_AI_2401_Config( card, wAdType, wAdType, wAdType, wAdType, P2401_AI_TRGSRC_SOFT );
    if(err != NoError)
    {
        printf("UD_AI_2401_Config Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);

    }
    
    err = UD_AI_2401_PollConfig(card, wPollSpeed, wMAvgStage, wMAvgStage, wMAvgStage, wMAvgStage );
    if(err != NoError)
    {
        printf("UD_AI_2401_PollConfig Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);

    }
    	    
    do{
        err = UD_AI_ReadMultiChannels(card, 1, Channel, AdRange, (U16*)(AIValue) );
        //err = UD_AI_ReadChannel(card, Channel[0], AdRange[0], (U16*)(&(AIValue[0])) );
        if(err != NoError){
            printf("UD_AI_ReadMultiChannels Error: %d\n", err);
            UD_Release_Card(card);
            exit(1);
        }

        clrscr();
        printf("------------------------------------\n");
        UD_AI_2401_Scale32(card, AdRange[0], wAdType, AIValue[0], &Voltage);
        printf("  Channel %d :\n", Channel[0]);
        printf("  Acquired Raw Data : 0x%08x\n", AIValue[0]);
        printf("  Scaled Voltage : %8.6lf\n", Voltage);
        printf("\n            Press Enter to exit...\n");
        printf("------------------------------------\n");
        usleep(10000);
    }while(!kbhit());

    err = UD_AI_2401_Stop_Poll (card); 
    if(err != NoError)
    {
        printf("UD_AI_2401_Stop_Poll() failed,  Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);
    }

    UD_Release_Card(card);
    
    return 0;
}
