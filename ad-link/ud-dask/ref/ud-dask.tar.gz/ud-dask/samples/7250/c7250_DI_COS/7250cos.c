#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/poll.h>
#include "udask.h"

#define DO_PORT 0
#define DI_PORT 0

int main(int argc, char **argv)
{
    I16 card, err;
    U16 card_num;
    U32 DI_Mask = 0x0001; // for DI0
    U32 CosData; 
    int n = 0;
    int timeout = 5000; // 5 seconds
    int hDev, result;
    struct pollfd pollfds;
    

    printf("This sample waits the COS interrupt on DI0.\n");

    printf("Card Number? ");
    n = scanf(" %hd", &card_num);
    if( n == 0 )
    {
       printf(" Only integar Card Number is valid \n" ); 
       exit(0);
    }

    card = UD_Register_Card(USB_7250, card_num);
    if(card<0){
        printf("Register_Card Error: %d\n", card);
        exit(1);
    }
    
    err = UD_Get_FileHandle(card, &hDev);
    if(err != NoError){
        printf("DO_Get_FileHandle() failed Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);
    }

    pollfds.fd = hDev;
    pollfds.events = POLLPRI; // wait for priority input 

    // enable the COS interrupt on DO8 
    err = UD_DI_SetCOSInterrupt32 (card, DI_PORT, DI_Mask);
    if(err != NoError){
        printf("DO_DI_SetCOSInterrupt32() Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);
    }

    do{
	result = poll( &pollfds, 1, timeout );
        if( result == -1 ) // error 
        {
           printf(" poll() failed, errno = %d \n", errno );
           break;
	}
	else if( result > 0 ) // successful
        {
	   if( (pollfds.revents & POLLPRI) != 0 )
  	   {
	       err = UD_DI_GetCOSLatchData32(card, DI_PORT, &CosData );
    	       if(err == NoError)
	         printf(" COS latched data : 0x%04X\n", CosData );
	       else	
                 printf("DO_DI_GetCOSLatchedData32() Error: %d\n", err);	
	   }
	}
	// else if (result == 0 ) // timeout

    }while(!kbhit());

    printf(" Press ENTER to Release_Card()\n"); getchar(); 

    // Reset DI COS Mask
    UD_DI_SetCOSInterrupt32 (card, DI_PORT, 0x0000);

    UD_Release_Card(card);
    return 0;
}
