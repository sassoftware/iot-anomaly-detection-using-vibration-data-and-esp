#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>
#include <string.h>
#include "udask.h"

#define AI_ACQCNT 2048                  /*Acquisition count per one trigger*/
#define AI_TRIGCNT 4                     /*Total Trigger count*/
#define AI_BUFCNT (AI_ACQCNT*AI_TRIGCNT) /*buffer size for all acquired data*/
#define CHANNELCOUNT 4                   /*AI Channel Count*/

int main(int argc, char **argv)
{
    I16 card, err;
    U16 card_num;
    U16 ChanCfg = UD_AI_Differential;
    U16 ConvSrc = UD_AI_CONVSRC_INT;	
    U16 TrigMode = UD_AI_TRGMOD_POST;     
    U16 TrigCtrl = (UD_AI_TRGSRC_AI0 | UD_AI_TrigPositive | UD_AI_EnReTrigger);
    U32 ReTriggerCount = AI_TRIGCNT; /*ReTrigger Count = Total Trigger Count*/
    U32 DLY1Cnt = 0; 
    U32 DLY2Cnt = 0;   
    U32 TriggerLvel = 0x1FFF; // 10V*  (0x7FFF/0x1FFF) = 2.5V      
    U16 RDBuffer[AI_BUFCNT]; /*Buffer to be setup*/
    F64 VBuffer[AI_BUFCNT];
    U32 AI_ReadCount = AI_ACQCNT; /*AI Read Count per one Trigger*/
    F64 fSamplerate = 200000.0f;    
    U16 NumChans = CHANNELCOUNT; /*AI Channel Count*/
    U16 Chans[CHANNELCOUNT]; /*AI Channels Array*/
    U16 AdRanges[CHANNELCOUNT]; /*AI Ranges Array*/
    BOOLEAN Ready;
    BOOLEAN StopFlag;
    U16 RdyTrigCnt;
    U32 AccessCnt;
    FILE *w_file;
    char FileName[] = "ai_data.dat";
    U32 i, j;
    int n;
    /*--------------------------------*/

    memset(RDBuffer, '\0', AI_BUFCNT*sizeof(U16));
    memset(VBuffer, '\0', AI_BUFCNT*sizeof(F64));
    
    if(!(w_file=fopen(FileName, "w"))){
        printf("file open error...\n");
        exit(1);
    }
    
    for( i=0; i<NumChans; i++ )
    {
        Chans[i] = i;
        AdRanges[i] = AD_B_10_V;
            
        fprintf(w_file, "Channel %d,", Chans[i]);
    }
    
    fprintf(w_file, "\n");

    printf("This sample performs continuous AI acquisition from randon %d AI Channels\n", NumChans);
    printf("with external digital retrigger at %6.3lf Hz scan rate.\n\n", fSamplerate);

    /*Open and Initialize Device*/
    printf("Card Number? ");
    n = scanf(" %hd", &card_num);
    if( n == 0 )
    {
       printf(" Only integar Card Number is valid \n" ); 
       exit(0);
    }
    card = UD_Register_Card(USB_1210, card_num);
    if(card<0){
        printf("UD_Register_Card Error: %d\n", card);
        fclose(w_file);
        exit(1);
    }

    /*Configure AI*/
    err = UD_AI_Channel_Config( card, ChanCfg, ChanCfg, ChanCfg, ChanCfg );
    if(err != NoError)
    {
        printf("UD_AI_Channel_Config Error: %d\n", err);
        UD_Release_Card(card);
        fclose(w_file);
        exit(1);
    }

    err = UD_AI_Trigger_Config( card, ConvSrc, TrigMode, TrigCtrl, ReTriggerCount, DLY1Cnt, DLY2Cnt, TriggerLvel );
    if(err != NoError)
    {
        printf("UD_AI_Trigger_Config Error: %d\n", err);
        UD_Release_Card(card);
        fclose(w_file);
        exit(1);
    }

    /*Disable Double Buffer Mode*/
    err = UD_AI_AsyncDblBufferMode(card, 0);
    if(err != NoError){
        printf("UD_AI_AsyncDblBufferMode Error: %d\n", err);
        UD_Release_Card(card);   
        fclose(w_file);             
        exit(1);
    }

    /*AI Acquisition Start*/
    printf("\nPress any key to start AI.\n");
    getch();
    printf("You can press Enter to stop...\n");

    err = UD_AI_ContReadMultiChannels(card, NumChans, Chans, AdRanges, (U16*)RDBuffer, AI_ReadCount, fSamplerate, ASYNCH_OP);
    if(err != NoError)
    {
        printf("UD_AI_ContReadMultiChannels Error: %d\n", err);
        UD_Release_Card(card);
        fclose(w_file);
        exit(1);
    }
    
    printf("\nAI Acquisition is started...\n");
    printf("Wait for External Analog Trigger from AI0...\n\n");
    do{
        /*Check ReTrigger Ready and AI Acquisition End*/
        err = UD_AI_AsyncReTrigNextReady(card, &Ready, &StopFlag, &RdyTrigCnt);
        if(err != NoError){
            printf("UD_AI_AsyncReTrigNextReady Error: %d\n", err);
            UD_AI_AsyncClear(card, &AccessCnt);
            UD_Release_Card(card);
            fclose(w_file);
            exit(1);
        }
        if(Ready){
            /*Trigger Ready with Next Trigger*/
            printf("Trigger Ready: %d, AIEnd: %d, Trigger Count: %d\n", Ready, StopFlag, RdyTrigCnt);
        }
        if(StopFlag){
            /*AI End*/
            printf("Trigger Ready: %d, AIEnd: %d, Trigger Count: %d\n", Ready, StopFlag, RdyTrigCnt);
            break;
        }
    }while(!kbhit());

    /*Clear AI Setting and Get Remaining data*/
    err = UD_AI_AsyncClear(card, &AccessCnt);
    if(err != NoError){
        printf("UD_AI_AsyncClear Error: %d\n", err);
        UD_Release_Card(card);
        fclose(w_file);
        exit(1);
    }

    if(StopFlag){
        printf("\nAI Acquisition Done... Acquired %d samples...\n", AccessCnt);
        printf("Write %d samples of Buffer to %s file...\n", AccessCnt, FileName);
        for(i=0; i<AccessCnt/NumChans; i++){
            for(j=0; j<NumChans; j++){
                UD_AI_VoltScale(card, AdRanges[j], (U16)(RDBuffer[i*NumChans+j]), &VBuffer[i*NumChans+j]);
                fprintf(w_file, "%f,  ", VBuffer[i*NumChans+j]);
            }
            fprintf(w_file,"\n");
        }
    }
    else{
        printf("\nAI Acquisition has been stopped... Acquired %d samples...\n", AccessCnt);
        printf("Write %d samples of Buffer0 to %s file...\n", AccessCnt, FileName);
        for(i=0; i<AccessCnt/NumChans; i++)
        {
            for(j=0; j<NumChans; j++)
            {
                UD_AI_VoltScale(card, AdRanges[j], (U16)(RDBuffer[i*NumChans+j]), &VBuffer[i*NumChans+j]);
                fprintf(w_file, "%f,  ", VBuffer[i*NumChans+j]);
            }
            fprintf(w_file,"\n");
        }
    }

    UD_Release_Card(card);
    fclose(w_file);

    printf("\nPress any key to exit...\n");
    getch();
    return 0;
}
