#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>
#include <string.h>
#include "udask.h"

#define AI_ACQCNT 40960
#define AI_BUFCNT AI_ACQCNT
#define CHANNELCOUNT 4

int main(int argc, char **argv)
{
    I16 card, err;
    U16 card_num;
    U16 ChanCfg = UD_AI_Differential;
    U16 ConvSrc = UD_AI_CONVSRC_INT;	
	  U16 TrigMode = UD_AI_TRGMOD_POST;
    U16 TrigCtrl = (UD_AI_TRGSRC_DTRIG | UD_AI_TrigPositive | UD_AI_EnReTrigger);    
    U32 TriggerLvel = 0;      
    U32 ReTriggerCount = 0; /*0: Infinite Trigger if retrigger is enabled*/
    U32 DLY1Cnt = 0; 
    U32 DLY2Cnt = 0; 
    U32 AI_ReadCount = AI_ACQCNT;
    F64 fSamplerate = 2000000.0f;    
    U16 NumChans = CHANNELCOUNT; /*AI Channel Number*/
    U16 Chans[CHANNELCOUNT]; /*Array of AI Channels to be read*/
    U16 AdRanges[CHANNELCOUNT]; /*Array of AI Ranges*/
    BOOLEAN Ready;
    BOOLEAN StopFlag;
    U16 RdyTrigCnt;
    U32 AccessCnt;
    U8 FileName[] = "ai_data";
    U32 UserTrigCount = 0;
    int n;
    U32 i;
    /*--------------------------------*/

    for( i=0; i<NumChans; i++ )
    {
        Chans[i] = i;
        AdRanges[i] = AD_B_10_V;
    }

    printf("This sample performs continuous AI acquisition from randon %d AI Channels\n", NumChans);
    printf("with infinite external digital trigger at %6.3lf Hz sampling rate.\n\n", fSamplerate);

    /*Open and Initialize Device*/
    printf("Card Number? ");
    n = scanf(" %hd", &card_num);
    if( n == 0 )
    {
       printf(" Only integar Card Number is valid \n" ); 
       exit(0);
    }
    card = UD_Register_Card(USB_1210, card_num);
    if(card<0){
        printf("UD_Register_Card Error: %d\n", card);
        exit(1);
    }

    /*Configure AI*/
    err = UD_AI_Channel_Config( card, ChanCfg, ChanCfg, ChanCfg, ChanCfg );
    if(err != NoError)
    {
        printf("UD_AI_Channel_Config Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);
    }

    err = UD_AI_Trigger_Config( card, ConvSrc, TrigMode, TrigCtrl, ReTriggerCount, DLY1Cnt, DLY2Cnt, TriggerLvel );
    if(err != NoError)
    {
        printf("UD_AI_Trigger_Config Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);
    }

    /*AI Acquisition Start*/
    err = UD_AI_ContReadMultiChannelsToFile(card, NumChans, Chans, AdRanges, FileName, AI_ReadCount, fSamplerate, ASYNCH_OP);
    if(err != NoError){
        printf("UD_AI_ContReadMultiChannelsToFile Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);
    }

    printf("You can press Enter to stop...\n");
    do{
        /*Check ReTrigger Ready and AI Acquisition End*/
        err = UD_AI_AsyncReTrigNextReady(card, &Ready, &StopFlag, &RdyTrigCnt);
        if(err != NoError){
            printf("AI_AsyncReTrigNextReady Error: %d\n", err);
            UD_AI_AsyncClear(card, &AccessCnt);
            UD_Release_Card(card);
            exit(1);
        }
        
        if(Ready){
            UserTrigCount++;
            /*Trigger Ready with Next Trigger*/
            printf("\nReady: %d, StopFlag: %d, TrigCnt: %d\n", Ready, StopFlag, RdyTrigCnt);
            if(RdyTrigCnt==0){
                printf("  Buffer 0 ready...\n");
                printf("  Write %d samples of Buffer0 to %s.dat file...\n", AI_ReadCount, FileName);
                UD_AI_AsyncDblBufferToFile(card);
            }
            else{
                printf("  Buffer 1 ready...\n");
                printf("  Write %d samples of Buffer1 to %s.dat file...\n", AI_ReadCount, FileName);
                UD_AI_AsyncDblBufferToFile(card);
            }
        }
    }while((!kbhit())&&(!StopFlag));

    /*Clear AI Setting and Get Remaining data*/
    err = UD_AI_AsyncClear(card, &AccessCnt);
    if(err != NoError){
        printf("AI_AsyncClear Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);
    }

    UD_Release_Card(card);

    printf("\nPress any key to exit...\n");
    getch();
    return 0;
}
