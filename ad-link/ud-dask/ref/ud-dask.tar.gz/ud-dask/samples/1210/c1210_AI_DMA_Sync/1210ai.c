#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>
#include <string.h>
#include "udask.h"

#define AI_COUNT 204800
#define CHANNELCOUNT 1

int main(int argc, char **argv)
{
    I16 card, err;
    U16 card_num;
    U16 ChanCfg = UD_AI_Differential;
    U16 ConvSrc = UD_AI_CONVSRC_INT;	
    U16 TrigMode = UD_AI_TRGMOD_POST;
    U16 TrigCtrl = UD_AI_TRGSRC_SOFT;    
    U32 ReTriggerCount = 0;
    U32 DLY1Cnt = 0;
    U32 DLY2Cnt = 0; 
    U32 TriggerLvel = 0;
    U16 RDBuffer[AI_COUNT];
    F64 VBuffer[AI_COUNT];
    U32 AI_ReadCount = AI_COUNT; /*AI read count per one buffer*/
    F64 fSamplerate = 200000.0f;    
    U32 AccessCnt = 0;
    int n;

    U16 Channel = 0; /*AI Channel Number to be read*/
    U16 AdRange = AD_B_10_V; /*AI range*/
    FILE *w_file;
    char FileName[] = "ai_data.dat";
    U32 i;
    /*--------------------------------*/

    memset(RDBuffer, '\0', AI_COUNT*sizeof(U16));
    memset(VBuffer, '\0', AI_COUNT*sizeof(F64));
    if(!(w_file=fopen(FileName, "w"))){
        printf("file open error...\n");
        exit(1);
    }
    fprintf(w_file, "Channel %d,\n", Channel);

    printf("This sample performs continuous AI acquisition from AI Channel %d\n", Channel);
    printf("at %6.3lf Hz sampling rate.\n\n", fSamplerate);

    /*Open and Initialize Device*/
    printf("Card Number? ");
    n = scanf(" %hd", &card_num);
    if( n == 0 )
    {
       printf(" Only integar Card Number is valid \n" ); 
       exit(0);
    }

    card = UD_Register_Card(USB_1210, card_num);
    if(card<0){
        printf("Register_Card Error: %d\n", card);
        fclose(w_file);
        exit(1);
    }

    /*Configure AI*/
    err = UD_AI_Channel_Config( card, ChanCfg, ChanCfg, ChanCfg, ChanCfg );    
    if(err != NoError)
    {
        printf("UD_AI_Channel_Config Error: %d\n", err);
        UD_Release_Card(card);
        fclose(w_file);
        exit(1);

    }
    										   
    err = UD_AI_Trigger_Config( card, ConvSrc, TrigMode, TrigCtrl, ReTriggerCount, DLY1Cnt, DLY2Cnt, TriggerLvel );
    if(err != NoError)
    {
        printf("UD_AI_Trigger_Config Error: %d\n", err);
        UD_Release_Card(card);
        fclose(w_file);
        exit(1);

    }
        
    /*Enable Double Buffer Mode*/
    err = UD_AI_AsyncDblBufferMode(card, 0); // double-buffer mode
    if(err != NoError)
    {
        printf("UD_AI_AsyncDblBufferMode Error: %d\n", err);
        UD_Release_Card(card);
        fclose(w_file);
        exit(1);
    }

    /*AI Acquisition Start*/
    err = UD_AI_ContReadChannel( card, Channel, AdRange, (U16*)RDBuffer, AI_ReadCount, fSamplerate, SYNCH_OP );
    if(err != NoError){
        printf("UD_AI_ContReadChannel Error: %d\n", err);
        UD_Release_Card(card);
        fclose(w_file);
        exit(1);
    }

    printf("\n\nAI Acquisition Done... Acquired %d samples...\n", AI_ReadCount);
    printf("Write %d samples of Buffer to %s file...\n", AI_ReadCount, FileName);
    UD_AI_ContVScale(card, AdRange, RDBuffer, VBuffer, AI_ReadCount);

    for(i=0; i<AI_ReadCount; i++)
    {
        fprintf(w_file, "%f,\n", VBuffer[i]);
    }

    err = UD_AI_AsyncClear(card, &AccessCnt);
    if(err != NoError)
    {
        printf("AI_AsyncClear Error: %d\n", err);
        UD_AI_AsyncClear(card, &AccessCnt);
        UD_Release_Card(card);
        fclose(w_file);
        exit(1);
    }

    fclose(w_file);
    UD_Release_Card(card);

    printf("\nPress any key to exit...\n");
    getch();
    return 0;
}
