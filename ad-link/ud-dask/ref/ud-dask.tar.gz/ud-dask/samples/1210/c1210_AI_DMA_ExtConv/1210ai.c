#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>
#include <string.h>
#include "udask.h"

#define AI_COUNT 10240

int main(int argc, char **argv)
{
    I16 card, err;
    U16 card_num;
    U16 ChanCfg = UD_AI_Differential;
    U16 ConvSrc = UD_AI_CONVSRC_EXT;	
    U16 TrigMode = UD_AI_TRGMOD_POST;
    U16 TrigCtrl = UD_AI_TRGSRC_SOFT; 
    U32 ReTriggerCount = 0;
    U32 DLY1Cnt = 0; 
    U32 DLY2Cnt = 0;
    U32 TriggerLvel = 0;    
    U16 RDBuffer[AI_COUNT];
    F64 VBuffer[AI_COUNT];
    U32 AI_ReadCount = AI_COUNT; /*AI read count*/
    U16 Channel = 0; /*AI Channel Number to be read*/
    U16 AdRange = AD_B_10_V; /*AI range*/
    BOOLEAN Stopped;
    U32 AccessCnt;
    FILE *w_file;
    char FileName[] = "ai_data.dat";
    U32 i;
    int n;
    /*--------------------------------*/

    memset(RDBuffer, '\0', AI_COUNT*sizeof(U16));
    memset(VBuffer, '\0', AI_COUNT*sizeof(F64));
    if(!(w_file=fopen(FileName, "w"))){
        printf("file open error...\n");
        exit(1);
    }
    fprintf(w_file, "Channel %d,\n", Channel);

    printf("This sample performs continuous AI acquisition from AI Channel %d\n", Channel);
    printf("with external conversion source (GPI0).\n\n");

    /*Open and Initialize Device*/
    printf("Card Number? ");
    n = scanf(" %hd", &card_num);
    if( n == 0 )
    {
       printf(" Only integar Card Number is valid \n" ); 
       exit(0);
    }

    card = UD_Register_Card(USB_1210, card_num);
    if(card<0){
        printf("UD_Register_Card Error: %d\n", card);
        fclose(w_file);
        exit(1);
    }

    /*Configure AI*/
    err = UD_AI_Channel_Config( card, ChanCfg, ChanCfg, ChanCfg, ChanCfg );    
    if(err != NoError)
    {
        printf("UD_AI_Channel_Config Error: %d\n", err);
        UD_Release_Card(card);
        fclose(w_file);
        exit(1);

    }

    err = UD_AI_Trigger_Config( card, ConvSrc, TrigMode, TrigCtrl, ReTriggerCount, DLY1Cnt, DLY2Cnt, TriggerLvel );
    if(err != NoError)
    {
        printf("UD_AI_Trigger_Config Error: %d\n", err);
        UD_Release_Card(card);
        fclose(w_file);
        exit(1);

    }
	
    /*Disable Double Buffer Mode*/
    err = UD_AI_AsyncDblBufferMode(card, 0);
    if(err != NoError){
        printf("AI_AsyncDblBufferMode Error: %d\n", err);
        UD_Release_Card(card);
        fclose(w_file);
        exit(1);
    }

    /*AI Acquisition Start*/
    printf("\nPress any key to start AI to wait external conversion souce.\n");
    printf("                            And you can press Enter to stop...\n");
    getch();
    err = UD_AI_ContReadChannel( card, Channel, AdRange, (U16*)RDBuffer, AI_ReadCount, 0.0f/*Ignore*/, ASYNCH_OP );    
    if(err != NoError){
        printf("AI_ContReadChannel Error: %d\n", err);
        UD_Release_Card(card);
        fclose(w_file);
        exit(1);
    }
    do{
        /*Check whether AI Acquisition is done*/
        err = UD_AI_AsyncCheck(card, &Stopped, &AccessCnt);
        if(err != NoError){
            printf("AI_AsyncCheck Error: %d\n", err);
            UD_AI_AsyncClear(card, &AccessCnt);
            UD_Release_Card(card);
            fclose(w_file);
            exit(1);
        }
    }while((!kbhit())&&(!Stopped));

    /*Clear AI Setting and Get Remaining data*/
    err = UD_AI_AsyncClear(card, &AccessCnt);
    if(err<0){
        printf("AI_AsyncClear Error: %d\n", err);
        UD_Release_Card(card);
        fclose(w_file);
        exit(1);
    }

    if(Stopped){
        printf("\n\nAI Acquisition Done... Acquired %d samples...\n", AccessCnt);
        printf("Write %d samples of Buffer to %s file...\n", AccessCnt, FileName);
        UD_AI_ContVScale(card, AdRange, RDBuffer, VBuffer, AccessCnt);
        for(i=0; i<AccessCnt; i++){
            fprintf(w_file, "%f,\n", VBuffer[i]);
        }
    }
    else{
        printf("\nAI Acquisition has been stopped manually... Acquired %d samples...\n", AccessCnt);
        printf("Write %d samples of Buffer to %s file...\n", AccessCnt, FileName);
        UD_AI_ContVScale(card, AdRange, RDBuffer, VBuffer, AccessCnt);
        for(i=0; i<AccessCnt; i++){
            fprintf(w_file, "%f,\n", VBuffer[i]);
        }
    }


    UD_Release_Card(card);
    fclose(w_file);

    printf("\nPress any key to exit...\n");
    getch();
    return 0;
}
