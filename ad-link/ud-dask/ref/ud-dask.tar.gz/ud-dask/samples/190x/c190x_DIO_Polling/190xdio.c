#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>
#include <string.h>
#include "udask.h"

#define DO_PORT 0
#define DI_PORT 0

int main(int argc, char **argv)
{
    I16 card, err;
    U16 card_num;
    U16 card_type;
    U32 DO_Write = 0x0;
    U32 DO_Read, DI_Read;
    int n = 0;

    printf("This sample write digital data to DO port and read digital value from DI port.\n");

    /*Select the Card Type*/
    printf("Card Type? (1) USB-1902   (2) USB-1903   (3) USB-1901: ");
    n = scanf(" %hd", &card_type);
    if( n == 0 )
    {
       printf(" Only integar Card Type is valid \n" ); 
       exit(0);
    }

    if( (card_type <1) || (card_type >3) ) 
    {
       printf(" Invalid Card Type\n" ); 
       exit(0);
    }

    /*Open and Initialize Device*/
    printf("Card Number? ");
    n = scanf(" %hd", &card_num);
    if( n == 0 )
    {
       printf(" Only integar Card Number is valid \n" ); 
       exit(0);
    }

    card = UD_Register_Card(card_type, card_num);
    if(card<0){
        printf("Register_Card Error: %d\n", card);
        exit(1);
    }

    if ((err = UD_DIO_1902_Config (card, GPI0_3_GPO0_1, GPI4_7_GPO2_3)) < 0 ) {
        printf("UD_DIO_1902_Config error=%d", err);
        UD_Release_Card( card );
        exit(2);
    }

    do{
        /*Write DO port*/
        err = UD_DO_WritePort(card, DO_PORT, DO_Write);
        if(err != NoError){
            printf("DO_WritePort Error: %d\n", err);
            UD_Release_Card(card);
            exit(1);
        }
        /*Read the written data from DO port*/
        err = UD_DO_ReadPort(card, DO_PORT, &DO_Read);
        if(err != NoError){
            printf("DO_ReadPort Error: %d\n", err);
            UD_Release_Card(card);
            exit(1);
        }
        /*Read DI Port*/
        err = UD_DI_ReadPort(card, DI_PORT, &DI_Read);
        if(err != NoError){
            printf("DI_ReadPort Error: %d\n", err);
            UD_Release_Card(card);
            exit(1);
        }
        clrscr();
        printf("/*--------------------------------*/\n");
        printf("  DO Write Data : 0x%04X\n", DO_Write);
        printf("  DO Read Data : 0x%04X\n", DO_Read);
        printf("  DI Read Data : 0x%04X\n", DI_Read);
        printf("\n\tPress Enter to exit...\n");
        printf("/*--------------------------------*/\n");

        if( DO_Write == 0x3 )
            DO_Write = 0;
        else
            DO_Write ++;

        usleep(100000);
    }while(!kbhit());

    UD_Release_Card(card);
    return 0;
}
