#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>
#include <string.h>
#include "udask.h"

#define READCOUNT 10240
#define U1902_TIMEBASE 80000000.0  // 80M

int main(int argc, char **argv)
{
    I16 card, err;
    U16 card_num;      
    U16 card_type;      
    U16 ConfigCtrl = P1902_AI_PseudoDifferential|P1902_AI_CONVSRC_INT;
    U16 TrigCtrl = P1902_AI_TRGMOD_DELAY | P1902_AI_TRGSRC_DTRIG | P1902_AI_TrgPositive;
    U32 TriggerLvel = 0;  /* Ignore for P1902_AI_TRGMOD_DELAY */
    U32 ReTriggerCount = 0; /*Ignore if trigger mode is gated trigger*/
    U32 DelayCount = 320000000; /* 320000000 / 80000000 = 4 second */
    U32 ScanIntrv = 800; /*Scan rate: U1902_TIMEBASE/80=100KHz*/
    U32 SampIntrv = 800; /*Sampling rate: U1902_TIMEBASE/80=100KHz*/
    U16 RDBuffer[READCOUNT];    
    F64 VBuffer[READCOUNT];
    U32 AI_ReadCount = READCOUNT; /*AI read count*/
    U16 Channel = 0; /*AI channel to be read*/
    U16 AdRange = AD_B_10_V; /*AI range*/
    BOOLEAN Stopped = FALSE;
    U32 AccessCnt = 0;
    FILE *w_file;
    char FileName[] = "ai_data.dat";
    U32 i;
    int n;

    memset(RDBuffer, '\0', READCOUNT*sizeof(U16));
    memset(VBuffer, '\0', READCOUNT*sizeof(F64));
    if(!(w_file = fopen(FileName, "w"))){
        printf("file open error...\n");
        exit(1);
    }
    fprintf(w_file, "Channel %d,\n", Channel);
    printf("This sample performs continuous AI acquisition with External Digital Trigger\n");
    printf("from AI Channel %d at %6.3lf Hz sampling rate.\n", Channel, U1902_TIMEBASE/SampIntrv);

    /*Select the Card Type*/
    printf("Card Type? (1) USB-1902   (2) USB-1903   (3) USB-1901: ");
    n = scanf(" %hd", &card_type);
    if( n == 0 )
    {
       printf(" Only integar Card Type is valid \n" ); 
       exit(0);
    }

    if( (card_type <1) || (card_type >3) ) 
    {
       printf(" Invalid Card Type\n" ); 
       exit(0);
    }

    /*Open and Initialize Devie*/
    printf("Card Number? ");
    n = scanf(" %hd", &card_num);
    if( n == 0 )
    {
       printf(" Only integar Card Number is valid \n" ); 
       exit(0);
    }
    card = UD_Register_Card(card_type, card_num);
    if(card<0){
        printf("UD_Register_Card Error: %d\n", card);
        fclose(w_file);
        exit(1);
    }

    /*Configure AI configurations*/
    err = UD_AI_1902_Config(card, ConfigCtrl, TrigCtrl, TriggerLvel, ReTriggerCount, DelayCount ); 
    if(err != NoError){
        printf("UD_AI_1902_Config Error: %d\n", err);
        UD_Release_Card(card);
        fclose(w_file);
        exit(1);
    }

    /*Set Counter Scan and Sample Interval*/
    err = UD_AI_1902_CounterInterval( card, ScanIntrv, SampIntrv );
    if(err != NoError){
        printf("UD_AI_1902_CounterInterval Error: %d\n", err);
        UD_Release_Card(card);    
        fclose(w_file);            
        exit(1);
    }
    
    /*Disable Double Buffer Mode*/
    err = UD_AI_AsyncDblBufferMode(card, 0);
    if(err != NoError){
        printf("UD_AI_AsyncDblBufferMode Error: %d\n", err);
        UD_Release_Card(card);   
        fclose(w_file);             
        exit(1);
    }

    /*Start AI Acquisition*/
    err = UD_AI_ContReadChannel( card, Channel, AdRange, (U16*)RDBuffer, AI_ReadCount, 0/*Ignore*/, ASYNCH_OP );
    if(err != NoError){
        printf("UD_AI_ContReadChannel Error: %d\n", err);
        UD_Release_Card(card);
        fclose(w_file);
        exit(1);
    }

    printf("\nWait Positive Trigger from AITG...\n");
    do{
        err = UD_AI_AsyncCheck(card, &Stopped, &AccessCnt);
        if(err != NoError){
            printf("AI_AsyncCheck Error: %d\n", err);
            UD_AI_AsyncClear(card, &AccessCnt);
            UD_Release_Card(card);
            fclose(w_file);
            exit(1);
        }
    }while((!kbhit())&&(!Stopped));

    err = UD_AI_AsyncClear(card, &AccessCnt);
    if(err != NoError){
        printf("AI_AsyncClear Error: %d\n", err);
        UD_AI_AsyncClear(card, &AccessCnt);
        UD_Release_Card(card);
        fclose(w_file);
        exit(1);
    }

    if(Stopped)
        printf("\n\nAI Acquisition done...\n");
    else
        printf("\n\nAI Acquisition has been stopped manually...\n");

    printf("Write %d samples of Buffer to %s file...\n\n", AccessCnt, FileName);
    fprintf(w_file, "Raw Data, Scaled Voltage,\n");
    UD_AI_ContVScale(card, AdRange, RDBuffer, VBuffer, AccessCnt);
    for(i=0; i<AccessCnt; i++){
        fprintf(w_file, "0x%x, %6.4f,\n", RDBuffer[i], VBuffer[i]);
    }

    UD_Release_Card(card);
    fclose(w_file);

    printf("\nPress any key to exit...\n");
    getch();
    return 0;
}
