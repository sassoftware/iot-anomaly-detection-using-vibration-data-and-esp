/*----------------------------------------------------------------------------*/
/* Company : ADLINK                                                           */
/* Date    : 2010/01/07                                                       */
/*                                                                            */
/* This sample performs continuous AI acquisition with Re-Trigger mode.       */
/* There are 16(Single Ended Mode)/8(Differetial Mode) AI channels in         */
/* USB-1902. You can use polling mode or DMA to acquired data from specified  */
/* channels.                                                                  */
/*----------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>
#include <string.h>
#include "udask.h"

#define AI_ACQCNT 16384                  /*Acquisition count per one trigger*/
#define AI_TRIGCNT 4                     /*Total Trigger count*/
#define AI_BUFCNT AI_ACQCNT*AI_TRIGCNT /*buffer size for all acquired data*/
#define CHANNELCOUNT 4                   /*AI Channel Count*/
#define U1902_TIMEBASE 80000000.0        /*Internal Timebase of USB-1902*/

int main(int argc, char **argv)
{
    I16 card, err;
    U16 card_num;
    U16 card_type;
    U16 ConfigCtrl = P1902_AI_PseudoDifferential|P1902_AI_CONVSRC_INT;
    U16 TrigCtrl = P1902_AI_TRGSRC_AI0|P1902_AI_TrgPositive|P1902_AI_EnReTigger;
    U32 TriggerLvel = 0;   
    U32 ReTriggerCount = AI_TRIGCNT; /*ReTrigger Count = Total Trigger Count*/
    U32 DelayCount = 0; /* Ignore w/o P1902_AI_TRGMOD_DELAY */
    U32 ScanIntrv = 320*CHANNELCOUNT; /*Scan Rate: U1902_TIMEBASE/320/4 = 62.5K Hz*/
    U32 SampIntrv = 320; /*Scan Rate: U1902_TIMEBASE/320 = 250K Hz*/
    U16 RDBuffer[AI_BUFCNT]; /*Buffer to be setup*/
    F64 VBuffer[AI_BUFCNT];
    U32 AI_ReadCount = AI_ACQCNT; /*AI Read Count per one Trigger*/
    U16 NumChans = CHANNELCOUNT; /*AI Channel Count*/
    U16 Chans[CHANNELCOUNT]; /*AI Channels Array*/
    U16 AdRanges[CHANNELCOUNT]; /*AI Ranges Array*/
    BOOLEAN Ready;
    BOOLEAN StopFlag;
    U16 RdyTrigCnt;
    U32 AccessCnt;
    FILE *w_file;
    char FileName[] = "ai_data.dat";
    U32 i, j;
    int n;
    /*--------------------------------*/

    memset(RDBuffer, '\0', AI_BUFCNT*sizeof(U16));
    memset(VBuffer, '\0', AI_BUFCNT*sizeof(F64));
    
    if(!(w_file=fopen(FileName, "w"))){
        printf("file open error...\n");
        exit(1);
    }
    
    for( i=0; i<NumChans; i++ )
    {
        Chans[i] = i;
        AdRanges[i] = AD_B_10_V;
            
        fprintf(w_file, "Channel %d,", Chans[i]);
    }
    
    fprintf(w_file, "\n");

    printf("This sample performs continuous AI acquisition from randon %d AI Channels\n", NumChans);
    printf("with external digital retrigger at %6.3lf Hz scan rate.\n\n", U1902_TIMEBASE/ScanIntrv);

    /*Select the Card Type*/
    printf("Card Type? (1) USB-1902   (2) USB-1903   (3) USB-1901: ");
    n = scanf(" %hd", &card_type);
    if( n == 0 )
    {
       printf(" Only integar Card Type is valid \n" ); 
       exit(0);
    }

    if( (card_type <1) || (card_type >3) ) 
    {
       printf(" Invalid Card Type\n" ); 
       exit(0);
    }

    /*Open and Initialize Device*/
    printf("Card Number? ");
    n = scanf(" %hd", &card_num);
    if( n == 0 )
    {
       printf(" Only integar Card Number is valid \n" ); 
       exit(0);
    }
    card = UD_Register_Card(card_type, card_num);
    if(card<0){
        printf("UD_Register_Card Error: %d\n", card);
        fclose(w_file);
        exit(1);
    }

    /*Configure AI*/
    err = UD_AI_1902_Config(card, ConfigCtrl, TrigCtrl, TriggerLvel, ReTriggerCount, DelayCount ); 
    if(err != NoError){
        printf("UD_AI_1902_Config Error: %d\n", err);
        UD_Release_Card(card);
        fclose(w_file);
        exit(1);
    }

    /*Set Scan and Sampling Rate*/
    err = UD_AI_1902_CounterInterval( card, ScanIntrv, SampIntrv );
    if(err != NoError){
        printf("UD_AI_1902_CounterInterval Error: %d\n", err);
        UD_Release_Card(card);    
        fclose(w_file);            
        exit(1);
    }

    /*Disable Double Buffer Mode*/
    /*Disable Double Buffer Mode*/
    err = UD_AI_AsyncDblBufferMode(card, 0);
    if(err != NoError){
        printf("UD_AI_AsyncDblBufferMode Error: %d\n", err);
        UD_Release_Card(card);   
        fclose(w_file);             
        exit(1);
    }

    /*AI Acquisition Start*/
    printf("\nPress any key to start AI.\n");
    getch();
    printf("You can press Enter to stop...\n");

    err = UD_AI_ContReadMultiChannels(card, NumChans, Chans, AdRanges, (U16*)RDBuffer, AI_ReadCount, 0/*Ignore*/, ASYNCH_OP);
    if(err != NoError)
    {
        printf("UD_AI_ContReadMultiChannels Error: %d\n", err);
        UD_Release_Card(card);
        fclose(w_file);
        exit(1);
    }
    
    printf("\nAI Acquisition is started...\n");
    printf("Wait for External Analog Trigger from AI0...\n\n");
    do{
        /*Check ReTrigger Ready and AI Acquisition End*/
        err = UD_AI_AsyncReTrigNextReady(card, &Ready, &StopFlag, &RdyTrigCnt);
        if(err != NoError){
            printf("UD_AI_AsyncReTrigNextReady Error: %d\n", err);
            UD_AI_AsyncClear(card, &AccessCnt);
            UD_Release_Card(card);
            fclose(w_file);
            exit(1);
        }
        if(Ready){
            /*Trigger Ready with Next Trigger*/
            printf("Trigger Ready: %d, AIEnd: %d, Trigger Count: %d\n", Ready, StopFlag, RdyTrigCnt);
        }
        if(StopFlag){
            /*AI End*/
            printf("Trigger Ready: %d, AIEnd: %d, Trigger Count: %d\n", Ready, StopFlag, RdyTrigCnt);
            break;
        }
    }while(!kbhit());

    /*Clear AI Setting and Get Remaining data*/
    err = UD_AI_AsyncClear(card, &AccessCnt);
    if(err != NoError){
        printf("UD_AI_AsyncClear Error: %d\n", err);
        UD_Release_Card(card);
        fclose(w_file);
        exit(1);
    }

    if(StopFlag){
        printf("\nAI Acquisition Done... Acquired %d samples...\n", AccessCnt);
        printf("Write %d samples of Buffer to %s file...\n", AccessCnt, FileName);
        for(i=0; i<AccessCnt/NumChans; i++){
            for(j=0; j<NumChans; j++){
                UD_AI_VoltScale(card, AdRanges[j], (U16)(RDBuffer[i*NumChans+j]), &VBuffer[i*NumChans+j]);
                fprintf(w_file, "%f,  ", VBuffer[i*NumChans+j]);
            }
            fprintf(w_file,"\n");
        }
    }
    else{
        printf("\nAI Acquisition has been stopped... Acquired %d samples...\n", AccessCnt);
        printf("Write %d samples of Buffer0 to %s file...\n", AccessCnt, FileName);
        for(i=0; i<AccessCnt/NumChans; i++)
        {
            for(j=0; j<NumChans; j++)
            {
                UD_AI_VoltScale(card, AdRanges[j], (U16)(RDBuffer[i*NumChans+j]), &VBuffer[i*NumChans+j]);
                fprintf(w_file, "%f,  ", VBuffer[i*NumChans+j]);
            }
            fprintf(w_file,"\n");
        }
    }

    UD_Release_Card(card);
    fclose(w_file);

    printf("\nPress any key to exit...\n");
    getch();
    return 0;
}
