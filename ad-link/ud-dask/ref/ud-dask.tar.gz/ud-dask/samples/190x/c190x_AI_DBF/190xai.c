#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>
#include <string.h>
#include "udask.h"

#define AI_COUNT		    20480
#define U1902_TIMEBASE 80000000.0  // 80M

int main(int argc, char **argv)
{
    I16 card, err;
    U16 card_num;
    U16 card_type;
    U16 ConfigCtrl = P1902_AI_PseudoDifferential|P1902_AI_CONVSRC_INT;
    U16 TrigCtrl = P1902_AI_TRGMOD_POST|P1902_AI_TRGSRC_SOFT;    
    U32 TriggerLvel = 0;  /* Ignore for P1902_AI_TRGSRC_SOFT */
    U32 ReTriggerCount = 0; /*Ignore in Double Buffer Mode*/    
    U32 DelayCount = 0; /* Ignore for P1902_AI_TRGSRC_SOFT */
    U32 ScanIntrv = 1600; /*Scan Interval: U1902_TIMEBASE/1600 = 20us*/
    U32 SampIntrv = 1600; /*Sample Interval: U1902_TIMEBASE/1600 = 20us (50K Hz)*/    
    U32 AI_ReadCount = AI_COUNT;
    U16 Channel = 0;
    U16 AdRange = AD_B_10_V;
    BOOLEAN Stopped = FALSE;
    BOOLEAN HalfReady = FALSE;
    U32 AccessCnt = 0;
    U16 BufIdx = 0;
    U16 overrunFlag = 0;
    U8 FileName[] = "ai_data";
    int n;
    /*--------------------------------*/

    printf("This sample performs infinite AI acquisition from AI Channel %d\n", Channel);
    printf("at %6.3lf Hz sampling rate by Double buffer mode.\n\n", U1902_TIMEBASE/SampIntrv);


    /*Select the Card Type*/
    printf("Card Type? (1) USB-1902   (2) USB-1903   (3) USB-1901: ");
    n = scanf(" %hd", &card_type);
    if( n == 0 )
    {
       printf(" Only integar Card Type is valid \n" ); 
       exit(0);
    }

    if( (card_type <1) || (card_type >3) ) 
    {
       printf(" Invalid Card Type\n" ); 
       exit(0);
    }

    /*Open and Initialize Device*/
    printf("Card Number? ");
    n = scanf(" %hd", &card_num);
    if( n == 0 )
    {
       printf(" Only integar Card Number is valid \n" ); 
       exit(0);
    }

    card = UD_Register_Card(card_type, card_num);
    if(card<0){
        printf("UD_Register_Card Error: %d\n", card);
        exit(1);
    }

    /*Configure AI*/
    err = UD_AI_1902_Config( card, ConfigCtrl, TrigCtrl, TriggerLvel, ReTriggerCount, DelayCount );    
    if(err != NoError){
        printf("UD_AI_1902_Config Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);
    }

    /*Set Scan and Sampling Rate*/
    err = UD_AI_1902_CounterInterval( card, ScanIntrv, SampIntrv );
    if(err != NoError){
        printf("UD_AI_1902_CounterInterval Error: %d\n", err);
        UD_Release_Card(card);        
        exit(1);
    }

    /*Enable Double Buffer Mode*/
		err = UD_AI_AsyncDblBufferMode(card, 1); // double-buffer mode
    if(err != NoError){
        printf("UD_AI_AsyncDblBufferMode Error: %d\n", err);
        UD_Release_Card(card);        
        exit(1);
    }

    BufIdx = 0;
    
    /*AI Acquisition Start*/
    err = UD_AI_ContReadChannelToFile(card, Channel, AdRange, FileName, AI_ReadCount, 50000/*Scan-Rate in Header*/, ASYNCH_OP);
    if(err != NoError){
        printf("AI_ContReadChannel Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);
    }
    
    printf("\nAI Infinite Acquisition is started...\n");
    do{
        /*Check Buffer Ready*/
        err = UD_AI_AsyncDblBufferHalfReady(card, &HalfReady, &Stopped);
        if(err != NoError){
            printf("UD_AI_AsyncDblBufferHalfReady Error: %d\n", err);
            UD_AI_AsyncClear(card, &AccessCnt);
            UD_Release_Card(card);
            exit(1);
        }
                

        if(HalfReady)
        {                    	
            if(BufIdx==0)
            {
                /*
                 * The acquired AI data are stored in buffer 0,
                 * You can process the data of buffer 0 in HERE if you need.
                 */
                printf("\nBuffer0 Half Ready...\n");
                printf("Write %d samples of Buffer0 to %s.dat file...\n", (AI_ReadCount/2), FileName);
                UD_AI_AsyncDblBufferToFile(card);
                UD_AI_AsyncDblBufferOverrun(card, 0, &overrunFlag);
                if(overrunFlag){
                    printf("OVERRUN...\n");
                    UD_AI_AsyncDblBufferOverrun(card, 1, &overrunFlag);
                }
                BufIdx = 1;
                printf("                              Press Enter to stop...\n");
            }
            else{
                /*
                 * The acquired AI data are stored in buffer 1,
                 * You can process the data of buffer 1 in HERE if you need.
                 */
                printf("\nBuffer1 Half Ready...\n");
                printf("Write %d samples of Buffer1 to %s.dat file...\n", (AI_ReadCount/2), FileName);
                UD_AI_AsyncDblBufferToFile(card);
                UD_AI_AsyncDblBufferOverrun(card, 0, &overrunFlag);
                if(overrunFlag){
                    printf("OVERRUN...\n");
                    UD_AI_AsyncDblBufferOverrun(card, 1, &overrunFlag);
                }
                BufIdx = 0;
                printf("                              Press Enter to stop...\n");
            }
        }
    }while(!kbhit());

    /*Clear AI Setting and Get Remaining data*/
    err = UD_AI_AsyncClear(card, &AccessCnt);
    if(err != NoError){
        printf("AI_AsyncClear Error: %d\n", err);
        UD_AI_AsyncClear(card, &AccessCnt);
        UD_Release_Card(card);
        exit(1);
    }

    UD_Release_Card(card);

    printf("\nPress any key to exit...\n");
    getch();
    return 0;
}
