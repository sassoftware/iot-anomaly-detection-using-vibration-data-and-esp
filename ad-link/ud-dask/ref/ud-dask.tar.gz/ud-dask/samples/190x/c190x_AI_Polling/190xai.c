#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>
#include <string.h>
#include "udask.h"


int main(int argc, char **argv)
{
    I16 card, err;
    U16 card_num;
    U16 card_type;

    U16 Channel = 0;
    U16 AdRange = AD_B_10_V;
    U16 Value;
    F64 Voltage;
    U16 ConfigCtrl = P1902_AI_PseudoDifferential;
    int n;

    printf("This sample acquires analog voltage from AI Channel 0 with polling mode.\n");

    /*Select the Card Type*/
    printf("Card Type? (1) USB-1902   (2) USB-1903   (3) USB-1901: ");
    n = scanf(" %hd", &card_type);
    if( n == 0 )
    {
       printf(" Only integar Card Type is valid \n" ); 
       exit(0);
    }

    if( (card_type <1) || (card_type >3) ) 
    {
       printf(" Invalid Card Type\n" ); 
       exit(0);
    }

    /*Open and Initialize Device*/
    printf("Card Number? ");
    n = scanf(" %hd", &card_num);
    if( n == 0 )
    {
       printf(" Only integar Card Number is valid \n" ); 
       exit(0);
    }

    card = UD_Register_Card(card_type, card_num);
    if(card<0){
        printf("UD_Register_Card Error: %d\n", card);
        exit(1);
    }

    /*Configure AI*/
    err = UD_AI_1902_Config( card, ConfigCtrl, 0x00, 0x00, 0x00, 0x00 );
    if(err != NoError)
    {
        printf("UD_AI_1902_Config Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);

    }

    do{
        err = UD_AI_ReadChannel(card, Channel, AdRange, &Value);
        if(err != NoError){
            printf("UD_AI_ReadChannel Error: %d\n", err);
            UD_Release_Card(card);
            exit(1);
        }

        clrscr();
        printf("------------------------------------\n");
        UD_AI_VoltScale(card, AdRange, Value, &Voltage);
        printf("  Channel %d :\n", Channel);
        printf("  Acquired Raw Data : 0x%x\n", Value);
        printf("  Scaled Voltage : %8.6lf\n", Voltage);
        printf("\n            Press Enter to exit...\n");
        printf("------------------------------------\n");
        usleep(10000);
    }while(!kbhit());

    UD_Release_Card(card);
    return 0;
}
