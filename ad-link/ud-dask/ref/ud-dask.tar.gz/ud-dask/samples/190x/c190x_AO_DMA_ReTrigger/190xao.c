#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#include "udask.h"

#ifndef   M_PI
#define   M_PI     3.14159265359
#endif

#define WRITECOUNT 0x4000
#define TIMEBASE 80000000.0  // 80M
#define UPDATEINTRV 3200
#define AO_SYNCTIMEOUT 5000

int main(int argc, char **argv)
{
    I16 card, err;
    U16 card_num;
    U16 card_type;
    U16 ConfigCtrl = P1902_AO_CONVSRC_INT;
    U16 TrigCtrl = P1902_AO_TRGMOD_POST|P1902_AO_TRGSRC_DTRIG|P1902_AO_TrgNegative|P1902_AO_EnReTigger;
    U32 ReTrgCnt = 5; //Ignored in non-retrigger mode
    U32 DLY1Cnt = 0; //Ignored in non-delay trigger mode
    U32 DLY2Cnt = 0; //Ignored in non-delay trigger mode
    U16 W_Buffer[WRITECOUNT];
    U32 WriteCount = WRITECOUNT;
    U16 Channel = 1;
    U32 Iterations = 1;
    U32 CHUI = UPDATEINTRV;
    U16 finite = 1;
    U32 vi;
    BOOLEAN Stopped;
    U32 AccessCnt = 0;    
    U32 TimeOut_ms = AO_SYNCTIMEOUT;
    int n;

    for(vi=0; vi<WriteCount; vi++){
        W_Buffer[vi] = (U16)( sin((double)vi/0x2000*M_PI)*0x7000); //+0x8000;
    }

    printf("This sample updates voltage to AO Channel %d\n", Channel);
    printf("at %.2f update rate, %.2f Hz Sine-Wave.\n", (float)TIMEBASE/UPDATEINTRV, (float)TIMEBASE/(UPDATEINTRV*0x4000) );

    /*Select the Card Type*/
    printf("Card Type? (1) USB-1902   (2) USB-1903: ");
    n = scanf(" %hd", &card_type);
    if( n == 0 )
    {
       printf(" Only integar Card Type is valid \n" ); 
       exit(0);
    }

    if( (card_type !=1) && (card_type !=2) ) 
    {
       printf(" Invalid Card Type\n" ); 
       exit(0);
    }

    /*Open and Initialize Device*/
    printf("Card Number? ");
    n = scanf(" %hd", &card_num);
    if( n == 0 )
    {
       printf(" Only integar Card Number is valid \n" ); 
       exit(0);
    }

    /*Open and initialize device*/
    card = UD_Register_Card(card_type, card_num);
    if(card<0){
        printf("UD_Register_Card Error: %d\n", card);
        exit(1);
    }

    /*Configure 1902 AO*/
    err = UD_AO_1902_Config(card, ConfigCtrl, TrigCtrl, ReTrgCnt, DLY1Cnt, DLY2Cnt);
    if(err != NoError){
        printf("UD_AO_1902_Config Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);
    }

    /*Enable FIFO Mode*/
    err = UD_AO_AsyncDblBufferMode(card, FALSE, TRUE);
    if(err != NoError){
        printf("UD_AO_AsyncDblBufferMode Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);
    }

    /*Start AO*/
    err = UD_AO_ContWriteChannel(card, Channel, (void*)W_Buffer, WriteCount, Iterations, CHUI, finite, ASYNCH_OP);    
    if(err != NoError){
        printf("UD_AO_ContWriteChannel Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);
    }

    do{
        err = UD_AO_AsyncCheck( card, &Stopped, &AccessCnt);
        if(err != NoError)
        {
            printf("AI_AsyncCheck Error: %d\n", err);
            UD_AO_AsyncClear(card, &AccessCnt, 0);
            UD_Release_Card(card);
            exit(1);
        }
        usleep(200);
    }while( (!kbhit()) && (!Stopped) );
    
    if( Stopped == 1 ) 
        printf("\n\nAO Update Done...\n");

    printf("Press any key to exit...\n");
    getch();

    UD_AO_AsyncClear(card, &AccessCnt, 0);
    UD_Release_Card(card);

    return 0;
}
