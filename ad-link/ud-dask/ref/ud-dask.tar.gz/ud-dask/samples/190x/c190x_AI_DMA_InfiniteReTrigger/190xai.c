#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>
#include <string.h>
#include "udask.h"

#define AI_ACQCNT 40960
#define AI_BUFCNT AI_ACQCNT
#define CHANNELCOUNT 4
#define U1902_TIMEBASE 80000000.0

int main(int argc, char **argv)
{
    I16 card, err;
    U16 card_num;
    U16 card_type;
    U16 ConfigCtrl = P1902_AI_PseudoDifferential|P1902_AI_CONVSRC_INT;
    U16 TrigCtrl = P1902_AI_TRGSRC_DTRIG|P1902_AI_TrgNegative|P1902_AI_EnReTigger;
    U32 TriggerLvel = 0;      
    U32 ReTriggerCount = 0; /*0: Infinite Trigger if retrigger is enabled*/
    U32 DelayCount = 0; /* Ignore w/o P1902_AI_TRGMOD_DELAY */    
    U32 ScanIntrv = 3200*CHANNELCOUNT; /*Scan Rate: U1902_TIMEBASE/20000/4=1K*/
    U32 SampIntrv = 3200; /*Sampling Rate: U1902_TIMEBASE/20000=4K*/
    U32 AI_ReadCount = AI_ACQCNT;
    U16 NumChans = CHANNELCOUNT; /*AI Channel Number*/
    U16 Chans[CHANNELCOUNT]; /*Array of AI Channels to be read*/
    U16 AdRanges[CHANNELCOUNT]; /*Array of AI Ranges*/
    BOOLEAN Ready;
    BOOLEAN StopFlag;
    U16 RdyTrigCnt;
    U32 AccessCnt;
    U8 FileName[] = "ai_data";
    U32 UserTrigCount = 0;
    int n;
    U32 i;
    /*--------------------------------*/

    for( i=0; i<NumChans; i++ )
    {
        Chans[i] = i;
        AdRanges[i] = AD_B_10_V;
    }

    printf("This sample performs continuous AI acquisition from randon %d AI Channels\n", NumChans);
    printf("with infinite external digital trigger at %6.3lf Hz sampling rate.\n\n", U1902_TIMEBASE/ScanIntrv);

    /*Select the Card Type*/
    printf("Card Type? (1) USB-1902   (2) USB-1903   (3) USB-1901: ");
    n = scanf(" %hd", &card_type);
    if( n == 0 )
    {
       printf(" Only integar Card Type is valid \n" ); 
       exit(0);
    }

    if( (card_type <1) || (card_type >3) ) 
    {
       printf(" Invalid Card Type\n" ); 
       exit(0);
    }

    /*Open and Initialize Device*/
    printf("Card Number? ");
    n = scanf(" %hd", &card_num);
    if( n == 0 )
    {
       printf(" Only integar Card Number is valid \n" ); 
       exit(0);
    }
    card = UD_Register_Card(card_type, card_num);
    if(card<0){
        printf("UD_Register_Card Error: %d\n", card);
        exit(1);
    }

    /*Configure AI*/
    err = UD_AI_1902_Config(card, ConfigCtrl, TrigCtrl, TriggerLvel, ReTriggerCount, DelayCount ); 
    if(err != NoError){
        printf("UD_AI_1902_Config Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);
    }

    /*Set Scan and Sampling Rate*/
    err = UD_AI_1902_CounterInterval( card, ScanIntrv, SampIntrv );
    if(err != NoError){
        printf("UD_AI_1902_CounterInterval Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);
    }

    /*AI Acquisition Start*/
    err = UD_AI_ContReadMultiChannelsToFile(card, NumChans, Chans, AdRanges, FileName, AI_ReadCount, 0/*Ignore*/, ASYNCH_OP);
    if(err != NoError){
        printf("UD_AI_ContReadMultiChannelsToFile Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);
    }

    printf("You can press Enter to stop...\n");
    do{
        /*Check ReTrigger Ready and AI Acquisition End*/
        err = UD_AI_AsyncReTrigNextReady(card, &Ready, &StopFlag, &RdyTrigCnt);
        if(err != NoError){
            printf("AI_AsyncReTrigNextReady Error: %d\n", err);
            UD_AI_AsyncClear(card, &AccessCnt);
            UD_Release_Card(card);
            exit(1);
        }
        
        if(Ready){
            UserTrigCount++;
            /*Trigger Ready with Next Trigger*/
            printf("\nReady: %d, StopFlag: %d, TrigCnt: %d\n", Ready, StopFlag, RdyTrigCnt);
            if(RdyTrigCnt==0){
                printf("  Buffer 0 ready...\n");
                printf("  Write %d samples of Buffer0 to %s.dat file...\n", AI_ReadCount, FileName);
                UD_AI_AsyncDblBufferToFile(card);
            }
            else{
                printf("  Buffer 1 ready...\n");
                printf("  Write %d samples of Buffer1 to %s.dat file...\n", AI_ReadCount, FileName);
                UD_AI_AsyncDblBufferToFile(card);
            }
        }
    }while((!kbhit())&&(!StopFlag));

    /*Clear AI Setting and Get Remaining data*/
    err = UD_AI_AsyncClear(card, &AccessCnt);
    if(err != NoError){
        printf("AI_AsyncClear Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);
    }

    UD_Release_Card(card);

    printf("\nPress any key to exit...\n");
    getch();
    return 0;
}
