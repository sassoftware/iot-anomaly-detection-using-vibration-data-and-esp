#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#include "udask.h"

#define WRITECOUNT 10240
#define TIMEBASE 80000000
#define UPDATEINTRV 3200

#ifndef   M_PI
#define   M_PI     3.14159265359
#endif

int main(int argc, char **argv)
{
    I16 card, err;
    U16 card_num;
    U16 card_type;
    U16 ConfigCtrl = P1902_AO_CONVSRC_INT;
    U16 TrigCtrl = P1902_AO_TRGMOD_POST|P1902_AO_TRGSRC_SOFT;
    U32 ReTrgCnt = 0; //Ignored in non-retrigger mode
    U32 DLY1Cnt = 0; //Ignored in non-delay trigger mode
    U32 DLY2Cnt = 0; //Ignored in non-delay2 mode
    U16 W_Buffer[WRITECOUNT];
    U32 WriteCount = WRITECOUNT;
    U32 HalfMemory;
    U16 *pBufAddr;
    U16 Channel = 1; //AO channel to be written
    U32 Iterations = 0; //Infinite repeate
    U32 CHUI = UPDATEINTRV;
    U16 finite = 0;
    U32 vi;
    BOOLEAN HalfReady;
    U32 AccessCnt;
    U16 RdyBufCnt = 0;
    int TargetBufId = 0;
    int n;
    
    for(vi=0; vi<WriteCount; vi++){
    	  W_Buffer[vi] = (U16)( sin((double)vi/0x1400*M_PI)*0x4000); //+0x8000;
    }

    HalfMemory = ( (WriteCount/2) * sizeof(U16) );
    
    printf("This sample infinitely updates voltage to AO Channel %d\n", Channel);
    printf("with double buffer mode at %.2f update rate, %.2f Hz Sine-Wave.\n", (float)TIMEBASE/UPDATEINTRV, (float)TIMEBASE/(UPDATEINTRV*0x2800) );

    /*Select the Card Type*/
    printf("Card Type? (1) USB-1902   (2) USB-1903: ");
    n = scanf(" %hd", &card_type);
    if( n == 0 )
    {
       printf(" Only integar Card Type is valid \n" ); 
       exit(0);
    }

    if( (card_type !=1) && (card_type !=2) ) 
    {
       printf(" Invalid Card Type\n" ); 
       exit(0);
    }

    /*Open and Initialize Device*/
    printf("Card Number? ");
    n = scanf(" %hd", &card_num);
    if( n == 0 )
    {
       printf(" Only integar Card Number is valid \n" ); 
       exit(0);
    }

    /*Open and initialize device*/
    card = UD_Register_Card(card_type, card_num);
    if(card<0){
        printf("Register_Card Error: %d\n", card);
        exit(1);
    }

    /*Configure 9222 AO*/
    err = UD_AO_1902_Config(card, ConfigCtrl, TrigCtrl, ReTrgCnt, DLY1Cnt, DLY2Cnt);
    if(err != NoError){
        printf("UD_AO_1902_Config Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);
    }

    /*Enable Double Buffer Mode*/
    err = UD_AO_AsyncDblBufferMode(card, TRUE, FALSE);
    if(err != NoError){
        printf("UD_AO_AsyncDblBufferMode Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);
    }

    /*Start AO DAC*/
    err = UD_AO_ContWriteChannel(card, Channel, (void*)W_Buffer, WriteCount, Iterations, CHUI, finite, ASYNCH_OP);
    if(err != NoError){
        printf("UD_AO_ContWriteChannel Error: %d\n", err);
        UD_Release_Card(card);
        exit(1);
    }

    do{
        err = UD_AO_AsyncDblBufferHalfReady(card, &HalfReady);
        if(err != NoError){
            printf("UD_AO_AsyncDblBufferHalfReady Error: %d\n", err);
            UD_Release_Card(card);
            exit(1);
        }
        if(HalfReady){
            printf("\nAO Buffer HalfReady\n");
            RdyBufCnt++;
            if(RdyBufCnt%2){
                /*
                 * AO buffer 0 is updated completely.
                 * You can do something (eg. set new updated data to AO buffer 0)
                 * in HERE if you need.
                 */
                printf("AO Buffer 0 is updated completely\n");
                printf("               You can press Enter to stop...\n");   
                TargetBufId = 0;
            }
            else{
                /*
                 * AO buffer 1 is updated completely.
                 * You can do something (eg. set new updated data to AO buffer 1)
                 * in HERE if you need.
                 */
                printf("AO Buffer 1 is updated completely\n");
                printf("               You can press Enter to stop...\n");  
                TargetBufId = 1;
            }
           
            pBufAddr = (U16*)( (char*)W_Buffer + (HalfMemory*TargetBufId)  );
            
            err = UD_AO_AsyncDblBufferTransfer(card, TargetBufId, pBufAddr);
            if(err != NoError){
                printf("UD_AO_AsyncDblBufferTransfer Error: %d\n", err);
                UD_Release_Card(card);
                exit(1);
            }            

			            
        }
        usleep(1000);
    }while(!kbhit());

    UD_AO_AsyncClear(card, &AccessCnt, 0);
    printf("\n\nAO Operation is stopped manually...\n");

    UD_Release_Card(card);

    printf("Press any key to exit...\n");
    getch();
    return 0;
}
