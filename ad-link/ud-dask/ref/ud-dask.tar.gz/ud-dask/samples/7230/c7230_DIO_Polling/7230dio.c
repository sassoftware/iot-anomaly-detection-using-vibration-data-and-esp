/*----------------------------------------------------------------------------*/
/* Company : ADLINK                                                           */
/* Date    : 2010/01/06                                                       */
/*                                                                            */
/* This sample performs DI read ans DO read/write with polling mode.          */
/*----------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>
#include <string.h>
#include "udask.h"

#define DO_PORT 0
#define DI_PORT 0

int main(int argc, char **argv)
{
    I16 card, err;
    U16 card_num;
    U32 DO_Write = 0x1;
    U32 DO_Read, DI_Read;
    int n = 0;

    printf("This sample write digital data to DO port and read digital value from DI port.\n");
    printf("Card Number? ");
    n = scanf(" %hd", &card_num);
    if( n == 0 )
    {
       printf(" Only integar Card Number is valid \n" ); 
       exit(0);
    }

    card = UD_Register_Card(USB_7230, card_num);
    if(card<0){
        printf("Register_Card Error: %d\n", card);
        exit(1);
    }

    do{
        /*Write DO port*/
        err = UD_DO_WritePort(card, DO_PORT, DO_Write);
        if(err != NoError){
            printf("DO_WritePort Error: %d\n", err);
            UD_Release_Card(card);
            exit(1);
        }
        /*Read the written data from DO port*/
        err = UD_DO_ReadPort(card, DO_PORT, &DO_Read);
        if(err != NoError){
            printf("DO_ReadPort Error: %d\n", err);
            UD_Release_Card(card);
            exit(1);
        }
        /*Read DI Port*/
        err = UD_DI_ReadPort(card, DI_PORT, &DI_Read);
        if(err != NoError){
            printf("DI_ReadPort Error: %d\n", err);
            UD_Release_Card(card);
            exit(1);
        }
        clrscr();
        printf("/*--------------------------------*/\n");
        printf("  DO Write Data : 0x%04X\n", DO_Write);
        printf("  DO Read Data : 0x%04X\n", DO_Read);
        printf("  DI Read Data : 0x%04X\n", DI_Read);
        printf("\n\tPress Enter to exit...\n");
        printf("/*--------------------------------*/\n");

        DO_Write = (DO_Write << 1);

        if( DO_Write > 0x8000 )
            DO_Write = 0x0001;

        usleep(250000);
    }while(!kbhit());

    UD_Release_Card(card);
    return 0;
}
