#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>
#include <string.h>
#include "udask.h"

int main(int argc, char **argv)
{
    I16 card, err;
    U16 card_num;
    U16 GCtr;
    U32 dwCtrl = UD_CTR_Filter_Disable;
    U32 GPTC_Val;
    F64 fFreq;
    int n;
    U16 MajorSelMode;

    printf("This sample performs Timer-Counter operations.\n");

    printf("Card Number? ");
    n = scanf(" %hd", &card_num);
    if( n == 0 )
    {
       printf(" Only integar Card Number is valid \n" ); 
       exit(0);
    }

    card = UD_Register_Card(USB_7230, card_num);
    if(card<0){
        printf("UD_Register_Card Error: %d\n", card);
        exit(1);
    }

    printf("CTR Number? [0~1] ");
    n = scanf(" %hd", &GCtr);
    if( n == 0 )
    {
       printf(" Only integar GPTC Number is valid \n" ); 
       goto ERR_RET;
    }

    if( (GCtr != 0) && (GCtr != 1) ){
        printf("Invalid counter number, set to GPTC 0...\n");
        printf("Press any key to continue...\n");
        getch();
        GCtr = 0;
    }

    dwCtrl = (UD_CTR_Filter_Disable | UD_CTR_Reset_Rising_Edge_Counter | UD_CTR_Reset_Frequency_Counter | UD_CTR_Polarity_Positive);

    err = UD_CTR_Control ( card, GCtr, dwCtrl);
    if(err != NoError){
        printf("UD_CTR_Control Error: %d\n", err);
        goto ERR_RET;
    }            

    clrscr();
    printf(" \n");
    printf(" (0) Read Edge Count.\n");
    printf(" (1) Read Frequency.\n");
    printf(" Which CTR mode to be performed? [0~1] ");
    n = scanf(" %hd", &MajorSelMode);
    if( n == 0 )
    {
       printf(" Only integar GPTC mode is valid \n" ); 
       goto ERR_RET;
    }

    if(MajorSelMode>1){
        printf(" Invalid Mode. set to Read Edge Count mode.\n");
        printf(" Press any key to continue...\n");
        getch();
        MajorSelMode = 0;
    }


    clrscr();
    switch(MajorSelMode)
    {
        case 0:
            do{
                err = UD_CTR_ReadEdgeCounter ( card, GCtr, &GPTC_Val );
                if(err != NoError){
                    printf("UD_CTR_ReadEdgeCounter Error: %d\n", err);
                    break; // exit while-loop
                }
                                
                clrscr();
                printf("/*---------------------------------*/\n");
                printf(" CTR Number: %d\n", GCtr);
                printf(" Read Edge Count: %d\n\n", GPTC_Val);
                printf("      You can press Enter to stop...\n");
                printf("/*---------------------------------*/\n");
                usleep(1000);
            }while(!kbhit());
            
            break;
            
        case 1:
            err = UD_CTR_ReadFrequency ( card, GCtr, &fFreq );
            if(err != NoError){
                printf("UD_CTR_ReadFrequency Error: %d\n", err);
                break; // exit switch-case
            }
            printf(" Pulse Frequency : %lf Hz.\n", fFreq);

            break;
    }

ERR_RET:
    UD_Release_Card(card);

    printf("\n Press any key to exit...\n");
    getch();
    return 0;
}

